window.location.href = "https://google.com";
